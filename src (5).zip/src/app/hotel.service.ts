import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HotelService {

  url:string='http://localhost:8080/hotel/';

  constructor(private http:HttpClient) { }

  
  getAllHotels()
  {
    return this.http.get(this.url);
  }

  findHotelById(hotelId:string)
  {
    return this.http.get(this.url+hotelId);
  }

  addHotel(hotel:any)
  {
    return this.http.post(this.url,hotel);
  }

  modifyHotel(hotel:any)
  {
    return this.http.put(this.url,hotel);
  }

  deleteHotel(hotelId:string)
  {
    return this.http.delete(this.url+hotelId);
  }

  findHotelByCity(city:string)
  {
    return this.http.get(this.url+"city/"+city);
  }
}
