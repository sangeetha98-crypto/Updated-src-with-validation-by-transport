import { Transport } from './transport';

describe('Transport', () => {
  it('should create an instance', () => {
    expect(new Transport()).toBeTruthy();
  });
});
