import { Customer } from "./customer";
import { Hotel } from "./hotel";

export class Booking {
    bookingId:string="" ;
    customer:Customer=new Customer(); 
    hotel:Hotel=new Hotel(); 
    bookingtype:string="";
    arrivalDate:Date=new Date(); 
    departureDate:Date=new Date(); 
    noOfPeople:number=0; 
    totalAmount:number=0;
}
