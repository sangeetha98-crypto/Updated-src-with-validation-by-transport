import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  url:string='http://localhost:8080/customer/';

  constructor(private http:HttpClient) { }

  getAllCustomer()
  {
    return this.http.get(this.url);
  }

  findCustomerById(customerId:string)
  {
    return this.http.get(this.url+customerId);
  }

  addCustomer(customer:any)
  {
    return this.http.post(this.url,customer);
  }

  modifyCustomer(customer:any)
  {
    return this.http.put(this.url,customer);
  }

  deleteCustomer(customerId:string)
  {
    return this.http.delete(this.url+customerId);
  }

}
